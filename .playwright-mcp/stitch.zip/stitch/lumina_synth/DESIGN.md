# Design System Specification: The Ethereal Canvas

## 1. Overview & Creative North Star
**Creative North Star: The Lucid Visionary**
This design system is built to bridge the gap between raw human imagination and refined AI execution. We move beyond "SaaS-standard" by embracing an editorial, immersive aesthetic that feels less like a utility and more like a high-end digital studio. 

The system rejects the rigid, "boxed-in" layout of traditional web apps. Instead, we utilize **Intentional Asymmetry** and **Bento-style depth** to create a rhythmic flow. By overlapping glassmorphic elements and using high-contrast typography scales, we evoke a sense of creative potential—where the interface feels as fluid as a sketch and as polished as a masterpiece.

---

## 2. Color & Tonal Architecture
The palette is rooted in a deep, midnight foundation, allowing our primary "Electric Blue" and "Vivid Violet" to vibrate with energy.

### Core Palette (Material Design Convention)
*   **Background:** `#090f16` (Deep Midnight)
*   **Primary (Blue):** `#93aaff` | **Primary Dim:** `#3d6af2`
*   **Secondary (Violet):** `#af88ff` | **Secondary Dim:** `#8a4cfc`
*   **Surface Tiers:**
    *   `surface_container_lowest`: `#000000` (Deepest voids)
    *   `surface_container`: `#131a23` (Standard cards)
    *   `surface_bright`: `#242d38` (Interactive surfaces)

### The "No-Line" Rule
**Borders are a failure of contrast.** This system strictly prohibits the use of 1px solid hex-color borders for sectioning. Boundaries must be defined solely through:
1.  **Background Shifts:** Placing a `surface_container_high` element against a `surface` background.
2.  **Tonal Transitions:** Using subtle value shifts to imply a change in context.
3.  **Shadow Depth:** Allowing soft, ambient occlusion to define the edge.

### Glassmorphism & Signature Textures
To create "Visual Soul," use the **Glass Layering** technique for floating panels (e.g., toolbars, property inspectors):
*   **Fill:** `surface_variant` at 60% opacity.
*   **Effect:** `Backdrop-blur: 20px`.
*   **The "Signature Glow":** Apply a linear gradient from `primary` to `secondary` at 15% opacity as a subtle background overlay on hero sections to break the flatness of the dark UI.

---

## 3. Typography: The Editorial Voice
We pair the technical precision of **Space Grotesk** for display with the humanist readability of **Manrope** for functional text.

*   **Display (Space Grotesk):** Large, bold, and unapologetic. Use `display-lg` (3.5rem) for hero statements with -2% letter spacing to create a compact, "designed" feel.
*   **Headlines (Space Grotesk):** `headline-md` (1.75rem) should be used for bento-grid titles, providing a clear entry point for the eye.
*   **Body (Manrope):** `body-lg` (1rem) is our workhorse. We prioritize line-height (1.6) to ensure the interface feels breathable and premium.
*   **Labels (Manrope Bold):** Used for pill-shaped tags and the "AI-Powered Art" badge. Always uppercase or title case with +5% letter spacing.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are replaced with **Ambient Luminescence.**

*   **The Layering Principle:** Stack `surface-container-lowest` cards on `surface-container-low` sections. This creates a "recessed" look, making the content feel like it's carved into the interface.
*   **Ambient Shadows:** For floating elements (Modals/Popovers), use a shadow with a 40px blur, 0px offset, and 8% opacity of the `primary_dim` color. This mimics the glow of a screen rather than a physical shadow.
*   **The Ghost Border Fallback:** If accessibility requires a border, use `outline_variant` at **15% opacity**. It should feel felt, not seen.

---

## 5. Components & UI Patterns

### The Signature Badge
*   **'AI-Powered Art' Badge:** A pill-shaped container using `primary_container` (20% opacity) with a `primary` text label. 
*   **Iconography:** Includes a `sparkle` icon (14px) leading the text. 
*   **Constraint:** Height must be exactly 24px.

### Buttons (The Interaction Core)
*   **Primary Gradient Button:** 
    *   **Min Height:** 44px (Standard) / 56px (Hero).
    *   **Fill:** Linear gradient (135deg) from `primary_dim` to `secondary_dim`.
    *   **Rounding:** `full` (Pill-shaped).
    *   **State:** On hover, increase the gradient saturation and add a 10px outer glow of the primary color.
*   **Tertiary Button:** Ghost style. No background, `primary` text, `manrope` bold.

### Bento Grid Layouts
*   **Spacing:** Use `spacing-6` (2rem) for gaps between bento cells.
*   **Corner Radii:** Use `rounded-lg` (2rem) for large containers and `rounded-md` (1.5rem) for internal nested elements.
*   **Composition:** Mix large `2x2` tiles with narrow `1x2` tiles to create a dynamic, non-repetitive rhythm.

### Input Fields & Controls
*   **Inputs:** Background uses `surface_container_highest`. No border. On focus, the background shifts to `surface_bright` with a subtle `primary` outer glow.
*   **Cards:** Forbid divider lines. Separate content using `spacing-4` (1.4rem) of vertical white space or by nesting a `surface_container_low` block within a `surface_container` card.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use asymmetrical margins to create a high-end editorial feel.
*   **Do** allow the background to bleed through glassmorphic elements to maintain a sense of place.
*   **Do** use the typography scale aggressively—high contrast between display and body text is key.
*   **Do** use the `primary` blue for functional actions and the `violet` accent for creative/AI-generative moments.

### Don’t:
*   **Don't** use 100% white (#FFFFFF) for text; use `on_surface` (#e9eef9) to prevent eye strain and maintain the "midnight" vibe.
*   **Don't** use sharp corners. Everything must feel approachable and organic.
*   **Don't** use standard "Drop Shadows." If it looks like a 2010 shadow, it’s too heavy.
*   **Don't** use dividers. If two pieces of content feel cluttered, add more space, don't add a line.